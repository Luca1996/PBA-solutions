#!/bin/bash
res=""
for i in {2..17}
do
  ((j=i+1))
  ./stage$i | g++ -x c++ - -o  stage$j
  tmp=$(./stage$i | grep -E "^int i, _" | cut -f2 -d "," | tr -d " _;")
  res+=$tmp
done  
echo $res
