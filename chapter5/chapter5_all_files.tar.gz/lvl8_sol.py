import string

with open('lvl8') as text:
    buf=""
    for line in text.readlines():
        for char in line:
            if char in string.ascii_lowercase:
                buf+="0"
            elif char in string.ascii_uppercase:
                buf+="1"
n = int(buf,2)
length = (n.bit_length()+7) // 8

with open('lvl8.bpm','wb') as out:
    out.write(n.to_bytes(length,byteorder='big'))